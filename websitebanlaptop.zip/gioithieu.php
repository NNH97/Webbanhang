<?php require_once __DIR__. "/autoload/autoload.php"; ?>
    <?php require_once __DIR__. "/layouts/header.php"; ?>

        <div class="col-md-9 bor">
            <section class="box-main1">
                <h3 class="title-main" style="text-align: center;"><a href="javascript:void(0)"> Giới thiệu cửa hàng </a> </h3>
                
                <p><strong>LT Shop-TỰ TIN MANG LẠI SỰ H&Agrave;I L&Ograve;NG CHO KH&Aacute;CH H&Agrave;NG!</strong><br />
				&nbsp;</p>

				<p>Thương hiệu&nbsp;<strong>LT Shop</strong>&nbsp;ch&iacute;nh thức ra đời v&agrave;o năm 2015, trụ sở cửa h&agrave;ng đặt tại&nbsp;<strong>601/12 CMT8, P15, Q10, TPHCM</strong>.<br />
				&nbsp;</p>

				<p><strong>LT Shop</strong>&nbsp;gồm 2 lĩnh vực hoạt động ch&iacute;nh: Chuy&ecirc;n cung cấp laptop, laptop cũ, laptop đ&atilde; qua sử dụng, laptop x&aacute;ch tay ch&iacute;nh h&atilde;ng nhập khẩu trực tiếp tại Mỹ, Nhật&hellip; Cung cấp sỉ v&agrave; lẻ tất cả c&aacute;c linh kiện li&ecirc;n quan tới laptop, như: RAM, CPU, HDD, LCD, Vỏ laptop, C&aacute;p m&agrave;n h&igrave;nh laptop, bản lề laptop&hellip;<br />
				&nbsp;</p>

				<p>Đến với ch&uacute;ng t&ocirc;i bạn c&oacute; thể trải nghiệm nhiều d&ograve;ng laptop: D&ograve;ng laptop chuy&ecirc;n GAME-VGA-Đồ họa, d&ograve;ng laptop chuy&ecirc;n văn ph&ograve;ng, d&ograve;ng laptop ultrabook mỏng nhẹ gọn tiện lợi mang đi lại&hellip; Bạn cũng c&oacute; thể chọn nhiều thương hiệu kh&aacute;c nhau tại&nbsp;<strong>LT Shop</strong>&nbsp;: laptop DELL, laptop HP, laptop Lenovo, Sony, Acer, Asus&hellip;<br />
				&nbsp;</p>

				<p><strong>LT Shop</strong>&nbsp;chắc chắn sẽ l&agrave;m h&agrave;i l&ograve;ng kh&aacute;ch h&agrave;ng về gi&aacute; b&aacute;n ra , thời gian phục vụ nhanh ch&oacute;ng, lu&ocirc;n vui vẻ phục vụ 24/24, tư vấn nhiệt t&igrave;nh, giải quyết thỏa đ&aacute;ng mọi ph&aacute;t sinh kh&ocirc;ng mong muốn khi qu&yacute; kh&aacute;ch h&agrave;ng mua sản phẩm tại LT Shop. Hướng tới phương thức b&aacute;n h&agrave;ng TRUNG THỰC nhất, tất cả laptop b&aacute;n ra đều được chụp h&igrave;nh thật đưa l&ecirc;n Website v&agrave; được đội ngũ kỹ thuật kiểm tra kỹ lưỡng trước khi đến tay người d&ugrave;ng.<br />
				&nbsp;</p>

				<p>D&ugrave; bạn l&agrave; ai, bạn tới để mua hay chỉ tới để tham khảo. Đừng ngại ngần! LT Shop lu&ocirc;n ch&agrave;o đ&oacute;n bạn!</p>

				<p>Cảm ơn c&aacute;c bạn đ&atilde; quan t&acirc;m, ủng hộ v&agrave; tin tưởng ch&uacute;ng t&ocirc;i!</p>


            </section>
        </div>
    <?php require_once __DIR__. "/layouts/footer.php"; ?>